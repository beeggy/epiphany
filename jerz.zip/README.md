OcsPanels
=========
Simple and lightweight panel for Reseller SSH based on Webmin API, 100% free.

Features
-------
* **Sistem Deposit** : Seller cukup Deposit, sudah bisa create Account SSH sendiri.
* **Remote Webmin** : cukup 1 panel bisa dipakai untuk banyak VPS.

Requirements
---------

##### Hosting
* PHP versi 5.3.4 keatas.
* MySQL versi 5.0.0 keatas.

##### VPS
* Webmin
* Perl XML::Parser Module (biasa otomatis terinstall bersama webmin)

Installation
------------
* Debian: https://www.hostingtermurah.net/tutorial-install-ocs-panel-pada-vps/
