<div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/home"><i class="fa fa-dashboard fa-lg fa-fw"></i>WENZSSH PANEL</a>
        </div>

        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search">
                        <div class="row">
                            <div class="col-xs-5">
                                <span class="fa-stack fa-3x">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-user fa-stack-1x fa-inverse"></i>
                                </span>
                            </div>
                            <div class="col-xs-7">
                                <h4><b><?php echo $me->username; ?></b></h4>
                                <h4 class="text-muted"><?php echo $me->type==1?'&#128081 Admin':'&#128100 Member'; ?></h4>
                            </div>
                        </div>
                    </li>

                    <?php if ($me->type==1): ?>
                        
                            <li>
                                <a href="/home/dashboard"><i class="fa fa-th-list fa-fw"></i> Dashboard</a>
                            </li>
                            <li>
                                <a href="/home/admin/seller"><i class="fa fa-group fa-fw"></i> Members</a>
                            </li>
<li>
<a href="/home/admin/server"><i class="fa fa-gear fa-fw"></i> Server settings</a>
</li>
                    <li>
                        <a href="/logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                        
<?php endif; ?>
<?php if ($me->type==2): ?>

                            <li>
                                <a href="/home/dashboard"><i class="fa fa-th-list fa-fw"></i> Dashboard</a>
                            </li>
                    <li>
                        <a href="/home/member/server"><i class="fa fa-shopping-cart fa-fw"></i> Create SSH</a>
                    </li>
                    <li>
                        <a href="/logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
<?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <?php echo $this->render($subcontent,$this->mime,get_defined_vars()); ?>
</div>
