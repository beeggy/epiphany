<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Server List
                <a href="<?php echo $URI; ?>/add" class="btn btn-default pull-right"><i class="fa fa-plus fa-fw"></i> Add Server</a>
            </h1>
        </div>
    </div>
    <div class="row">
        <?php if ($message): ?>
            <div class="col-lg-12">
                <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
            </div>
        <?php endif; ?>
        <?php foreach (($servers?:array()) as $server): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <b>「 <?php echo $server->servername; ?> 」</b> <?php echo $server->active==1?'':'( Locked )'; ?>
                    </div>
                    <table class="table">
                        <tr>
                            <td>Location</td><td><?php echo $server->country; ?></td>
                        </tr>
                        <tr>
                            <td>Host</td><td><?php echo $server->host; ?></td>
                        </tr>
                        <tr>
                            <td>Price</td><td><?php echo $server->price; ?> chips</td>
                        </tr>
                    </table>
                    <div class="panel-footer text-center">
                        <a href="<?php echo $URI.'/'.$server->id; ?>" class="btn btn-primary"><i class="fa fa-edit fa-fw"></i> Edit</a>
                        <a href="<?php echo $URI.'/'.$server->id; ?>/account" class="btn btn-default"><i class="fa fa-group fa-fw"></i> Accounts</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
