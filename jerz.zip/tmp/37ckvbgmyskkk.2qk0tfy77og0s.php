<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><center>= MAIN =</center></h1>        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-th-list fa-fw"></i> Dashboard
                </div>
                <div class="panel-body">
                Hello <b>「 <?php echo $me->username; ?> 」</b> welcome to WENZSSH panel!
<br/><br/>
<?php if ($me->type==1): ?>
<b>Account type:</b> <u>ADMIN</u>
<?php endif; ?>
<?php if ($me->type==2): ?>
<b>Account type:</b> <u>FREE</u>
<br/>
<b>Balance:</b> <u><?php echo $me->saldo; ?> chips</u>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
