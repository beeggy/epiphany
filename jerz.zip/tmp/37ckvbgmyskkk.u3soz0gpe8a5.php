<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                Create your SSH Account
            </h1>
        </div>
    </div>
    <div class="row">
        <?php if ($message): ?>
            <div class="col-lg-12 hidden-print">                    
                <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
            </div>
        <?php endif; ?>
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-user fa-fw"></i> Account Details
                </div>
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <td>Username</td><td><?php echo $user->user; ?></td>
                        </tr>
                        <tr>
                            <td>Password</td><td><?php echo $user->pass; ?></td>
                        </tr>
                        <tr>
                            <td>Host</td><td><?php echo $server->host; ?></td>
                        </tr>
<tr>
<td>SSH Port</td><td>22</td>
</tr>
<tr>
<td>SSL Port</td><td>443</td>
</tr>
<tr>
<td>Dropbear Port</td><td>442</td>
</tr>
                        <tr>
                            <td>Location</td><td><?php echo $server->country; ?></td>
                        </tr>
                        <tr>
                            <td>Price</td><td><?php echo $server->price; ?> chips</td>
                        </tr>
                        <tr>
                            <td>Expiration</td><td><?php echo \Webmin::exp_decode($user->expire); ?></td>
                        </tr>
                        <tr class="hidden-print">
                            <td colspan="2">
                                <a href="#" class="btn btn-primary" onclick="print_report()">Print</a>
                                <a href="/home/member/server" class="btn btn-default">Back</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
