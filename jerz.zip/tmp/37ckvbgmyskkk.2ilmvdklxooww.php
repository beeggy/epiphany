<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Dashboard</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-gear fa-fw"></i> Dashboard
                </div>
                <div class="panel-body">
                Hello <b>「 <?php echo $me->username; ?> 」</b> welcome to WENZSSH panel!
                </div>
            </div>
        </div>
    </div>
</div>
